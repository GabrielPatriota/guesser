import random
x = random.randint(0,100)